
import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate
{
    @IBOutlet weak var map: MKMapView!
    
    let locManager = CLLocationManager()
    
    override func viewDidLoad()
    {   super.viewDidLoad()
        
        map.showsUserLocation = true
        
        if CLLocationManager.locationServicesEnabled()
        {
            switch (CLLocationManager.authorizationStatus())
            {
            case .notDetermined , .restricted , .denied :
                print("You don't have access!!")
            case .authorizedAlways , .authorizedWhenInUse :
                print("Access granted!!")
            }
            
        }
        else
        {
            print("Location service is nor enabled!!")
        }
        
        locManager.delegate = self
        locManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locManager.requestWhenInUseAuthorization()
        locManager.requestAlwaysAuthorization()
        locManager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let cls = locations[0]
        let lat = cls.coordinate.latitude
        let long = cls.coordinate.longitude
        print("\nLatitude : \(lat)\n")
        print("\nLongitude : \(long)\n")
        
        CLGeocoder().reverseGeocodeLocation(cls) { (placemark, error) in
         
            if error != nil
            {
                print("\nFailed with error : \(String(describing: error?.localizedDescription))\n")
            }
            
            if (placemark?.count)! > 0
            {
                let pm = placemark?[0]
                print("\nLocality : \(String(describing: pm?.locality))\n")
                print("\nSub locality : \(String(describing: pm?.subLocality))\n")
                print("\nCountry : \(String(describing: pm?.country))\n")
                print("\nPostal code : \(String(describing: pm?.postalCode))")
                print("\nName : \(String(describing: pm?.name))\n")
                print("\nOcean : \(pm?.ocean)\n")
            }
            else
            {
                print("\nProblem with received data from geocoder!!\n")
            }
        }
        locManager.stopUpdatingLocation()
        let center = CLLocationCoordinate2D(latitude: lat, longitude: long)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        self.map.setRegion(region, animated: true)
        let NYLocation = CLLocationCoordinate2DMake(lat, long)
        let pin = MKPointAnnotation()
        pin.coordinate = NYLocation
        pin.title = "New York City"
        map.addAnnotation(pin)
    }

}

